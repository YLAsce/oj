#include<stdio.h>
main()
{
      int t,n,p,i;
      char a[12]={'A','B','C','D','E','F','G','H','I','J','K','L'};
      scanf("%d",&t);
      while(t--)
      {
          scanf("%d",&n);
          p=n-1984;
          if(p%10==0)
          {
          printf("0A\n");
          }
          else if(p%10>0)
          {
             printf("%d%c\n",(p%10),a[p%12]);
          }
          else
          {
              p*=-1;
              if (p%12!=0)
              printf("%d%c\n",(10-p%10),a[12-p%12]);
              else
              printf("%dA\n",(10-p%10));
          }
      }
      return;
}
