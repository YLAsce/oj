import pika

class JudgeQueue(object):
    pass
