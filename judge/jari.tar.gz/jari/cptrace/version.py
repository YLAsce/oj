PACKAGE = "cptrace"
VERSION = "0.6.1"
WEBSITE = "http://python-ptrace.hachoir.org/"
LICENSE = "GNU GPL v2"
