#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pika
import json
from conf import JudgeConf as jcnf
from compile import Compile
from sub import Sub
from judge import Judge

def daemon():
    try:
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            host='localhost'))
        chnlIn = connection.channel()
        chnlOut = connection.channel()

        chnlIn.queue_declare(queue='judge', durable=True)
        chnlOut.queue_declare(queue='ret', durable=True)
        print ' [*] Waiting for submissions. To exit press CTRL+C'

        def callback(ch, method, properties, body):
            print " [x] Received judge request %r" % (body,)
            s = Sub()
            s.getSub(body)
            try:
                c = Compile()
                c.compile(s)
            except Exception, e:
                print 'compile err| ', Exception, ':', e

            if s.status == jcnf.SUB_STATUS['judging']:
                try:
                    j = Judge()
                    j.judge(s)
                except Exception, e:
                    print 'judge err| ', Exception, ':', e
            elif s.status != jcnf.SUB_STATUS['compilation error']:
                print 'compile done but unknown status=', s.status

            retStr = s.retSub()
            chnlOut.basic_publish(
                    exchange='',
                    routing_key='ret',
                    body=retStr,
                    properties=pika.BasicProperties(
                        delivery_mode = 2,
                        )
                    )
            print " [x] Done judge result %r" % (retStr,)
            ch.basic_ack(delivery_tag=method.delivery_tag)

        chnlIn.basic_qos(prefetch_count=1)
        chnlIn.basic_consume(callback,
                queue='judge',)

        chnlIn.start_consuming()
    except KeyboardInterrupt:
        print 'jari deamon exit'
        connection.close()

if __name__ == '__main__':
    daemon()

